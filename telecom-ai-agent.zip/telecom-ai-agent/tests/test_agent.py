"""
tests/test_agent.py
────────────────────
Tests for the TelecomAgent agentic loop and ChatSession.
"""
from __future__ import annotations

import pytest
from unittest.mock import patch, MagicMock

from src.agent.agent import TelecomAgent, ChatSession
from src.agent.claude_client import ClaudeBedrockClient


class TestChatSession:

    def test_new_session_has_unique_id(self):
        s1 = ChatSession()
        s2 = ChatSession()
        assert s1.session_id != s2.session_id

    def test_session_starts_empty(self):
        session = ChatSession()
        assert session.messages == []
        assert session.tool_call_count == 0

    def test_session_stores_customer_id(self):
        session = ChatSession(customer_id="CUST-10001")
        assert session.customer_id == "CUST-10001"


class TestTelecomAgent:

    @patch.object(ClaudeBedrockClient, "_build_client")
    def setup_agent(self, mock_build):
        """Helper – create agent with mocked Bedrock client."""
        mock_build.return_value = MagicMock()
        return TelecomAgent()

    @patch.object(ClaudeBedrockClient, "_build_client")
    def test_new_session(self, mock_build):
        mock_build.return_value = MagicMock()
        agent = TelecomAgent()
        session = agent.new_session(customer_id="CUST-10001")
        assert session.customer_id == "CUST-10001"
        assert isinstance(session, ChatSession)

    @patch.object(ClaudeBedrockClient, "converse")
    @patch.object(ClaudeBedrockClient, "_build_client")
    def test_simple_chat(self, mock_build, mock_converse):
        """Agent returns final text when stop_reason is end_turn."""
        mock_build.return_value = MagicMock()
        mock_converse.return_value = {
            "stopReason": "end_turn",
            "output": {
                "message": {
                    "role": "assistant",
                    "content": [{"text": "Hello! How can I help you today?"}],
                }
            },
        }

        agent = TelecomAgent()
        session = agent.new_session()
        response = agent.chat(session, "Hi there!")

        assert response == "Hello! How can I help you today?"
        assert len(session.messages) == 2  # user + assistant

    @patch.object(ClaudeBedrockClient, "converse")
    @patch.object(ClaudeBedrockClient, "_build_client")
    def test_agent_calls_tool_then_responds(self, mock_build, mock_converse):
        """Agent executes a tool call and then returns a final response."""
        mock_build.return_value = MagicMock()

        call_count = {"n": 0}

        def side_effect(**kwargs):
            call_count["n"] += 1
            if call_count["n"] == 1:
                return {
                    "stopReason": "tool_use",
                    "output": {
                        "message": {
                            "role": "assistant",
                            "content": [
                                {
                                    "toolUse": {
                                        "toolUseId": "tu-001",
                                        "name": "get_account_info",
                                        "input": {"customer_id": "CUST-10001"},
                                    }
                                }
                            ],
                        }
                    },
                }
            else:
                return {
                    "stopReason": "end_turn",
                    "output": {
                        "message": {
                            "role": "assistant",
                            "content": [{"text": "Your plan is Unlimited Pro at $75/month."}],
                        }
                    },
                }

        mock_converse.side_effect = side_effect

        agent = TelecomAgent()
        session = agent.new_session(customer_id="CUST-10001")
        response = agent.chat(session, "What plan am I on?")

        assert "Unlimited Pro" in response
        assert call_count["n"] == 2
        assert session.tool_call_count == 1

    @patch.object(ClaudeBedrockClient, "converse")
    @patch.object(ClaudeBedrockClient, "_build_client")
    def test_agent_respects_max_iterations(self, mock_build, mock_converse):
        """Agent stops looping after max_tool_iterations."""
        mock_build.return_value = MagicMock()

        # Always return tool_use (infinite loop guard)
        mock_converse.return_value = {
            "stopReason": "tool_use",
            "output": {
                "message": {
                    "role": "assistant",
                    "content": [
                        {
                            "toolUse": {
                                "toolUseId": "tu-loop",
                                "name": "get_account_info",
                                "input": {"customer_id": "CUST-10001"},
                            }
                        }
                    ],
                }
            },
        }

        agent = TelecomAgent()
        session = agent.new_session()
        session.max_tool_iterations = 3  # cap low for test speed

        response = agent.chat(session, "test loop")
        # Should not raise and should return fallback message
        assert isinstance(response, str)

    @patch.object(ClaudeBedrockClient, "_build_client")
    def test_chat_appends_messages(self, mock_build):
        """Each chat turn should extend the session message list."""
        mock_build.return_value = MagicMock()

        with patch.object(ClaudeBedrockClient, "converse") as mock_converse:
            mock_converse.return_value = {
                "stopReason": "end_turn",
                "output": {
                    "message": {
                        "role": "assistant",
                        "content": [{"text": "Reply 1"}],
                    }
                },
            }

            agent = TelecomAgent()
            session = agent.new_session()

            agent.chat(session, "Turn 1")
            assert len(session.messages) == 2

            agent.chat(session, "Turn 2")
            assert len(session.messages) == 4  # cumulative


class TestClaudeBedrockClient:

    @patch.object(ClaudeBedrockClient, "_build_client")
    def test_build_user_message(self, mock_build):
        mock_build.return_value = MagicMock()
        client = ClaudeBedrockClient()
        msg = client.build_user_message("Hello")
        assert msg["role"] == "user"
        assert msg["content"][0]["text"] == "Hello"

    @patch.object(ClaudeBedrockClient, "_build_client")
    def test_extract_text(self, mock_build):
        mock_build.return_value = MagicMock()
        client = ClaudeBedrockClient()
        response = {
            "output": {
                "message": {
                    "content": [{"text": "Extracted text"}]
                }
            }
        }
        assert client.extract_text(response) == "Extracted text"

    @patch.object(ClaudeBedrockClient, "_build_client")
    def test_extract_text_empty(self, mock_build):
        mock_build.return_value = MagicMock()
        client = ClaudeBedrockClient()
        assert client.extract_text({}) == ""

    @patch.object(ClaudeBedrockClient, "_build_client")
    def test_build_tool_result_message(self, mock_build):
        mock_build.return_value = MagicMock()
        client = ClaudeBedrockClient()
        msg = client.build_tool_result_message("tu-001", {"result": "ok"})
        assert msg["role"] == "user"
        assert "toolResult" in msg["content"][0]
        assert msg["content"][0]["toolResult"]["toolUseId"] == "tu-001"
