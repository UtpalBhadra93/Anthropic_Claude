"""
tests/test_api.py
──────────────────
Integration tests for the FastAPI application.
Uses httpx AsyncClient and mocks Bedrock to avoid real AWS calls.
"""
from __future__ import annotations

import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
from unittest.mock import patch, MagicMock

from src.agent.claude_client import ClaudeBedrockClient


# ── Fixture: test app ────────────────────────────────────────────────────
@pytest.fixture(scope="module")
def app():
    with patch.object(ClaudeBedrockClient, "_build_client", return_value=MagicMock()):
        from src.api.app import create_app
        return create_app()


@pytest_asyncio.fixture
async def client(app):
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac


# ══════════════════════════════════════════════════════════════════════════
# Health
# ══════════════════════════════════════════════════════════════════════════
class TestHealth:

    @pytest.mark.asyncio
    async def test_health_check(self, client):
        resp = await client.get("/api/v1/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert "timestamp" in data


# ══════════════════════════════════════════════════════════════════════════
# Account Endpoints
# ══════════════════════════════════════════════════════════════════════════
class TestAccountEndpoints:

    @pytest.mark.asyncio
    async def test_get_account_found(self, client):
        resp = await client.get("/api/v1/account/CUST-10001")
        assert resp.status_code == 200
        data = resp.json()
        assert data["customer_id"] == "CUST-10001"
        assert data["name"] == "Alice Johnson"

    @pytest.mark.asyncio
    async def test_get_account_not_found(self, client):
        resp = await client.get("/api/v1/account/CUST-INVALID")
        assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_get_account_exclude_usage(self, client):
        resp = await client.get("/api/v1/account/CUST-10001?include_usage=false")
        assert resp.status_code == 200
        data = resp.json()
        assert "data_usage_gb" not in data


# ══════════════════════════════════════════════════════════════════════════
# Network Endpoints
# ══════════════════════════════════════════════════════════════════════════
class TestNetworkEndpoints:

    @pytest.mark.asyncio
    async def test_network_status_by_zip(self, client):
        resp = await client.get("/api/v1/network/status?zip_code=78701")
        assert resp.status_code == 200
        data = resp.json()
        assert "overall_status" in data

    @pytest.mark.asyncio
    async def test_network_status_by_customer(self, client):
        resp = await client.get("/api/v1/network/status?customer_id=CUST-10001")
        assert resp.status_code == 200
        data = resp.json()
        assert data["zip_code"] == "78701"

    @pytest.mark.asyncio
    async def test_network_status_no_params(self, client):
        resp = await client.get("/api/v1/network/status")
        assert resp.status_code == 400


# ══════════════════════════════════════════════════════════════════════════
# Plans Endpoints
# ══════════════════════════════════════════════════════════════════════════
class TestPlanEndpoints:

    @pytest.mark.asyncio
    async def test_list_plans(self, client):
        resp = await client.get("/api/v1/plans")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 4

    @pytest.mark.asyncio
    async def test_change_plan(self, client):
        from src.tools.plan_tool import _CUSTOMER_PLANS
        resp = await client.post(
            "/api/v1/plans/change",
            json={"customer_id": "CUST-10002", "plan_id": "PLAN-STANDARD-5G"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        # Restore
        _CUSTOMER_PLANS["CUST-10002"] = "PLAN-BASIC-5G"

    @pytest.mark.asyncio
    async def test_change_plan_invalid(self, client):
        resp = await client.post(
            "/api/v1/plans/change",
            json={"customer_id": "CUST-99999", "plan_id": "PLAN-BASIC-5G"},
        )
        assert resp.status_code == 400


# ══════════════════════════════════════════════════════════════════════════
# RAG Endpoints
# ══════════════════════════════════════════════════════════════════════════
class TestRAGEndpoints:

    @pytest.mark.asyncio
    async def test_rag_search(self, client):
        resp = await client.post(
            "/api/v1/rag/search",
            json={"query": "billing payment methods", "top_k": 3},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "results" in data
        assert data["total"] <= 3

    @pytest.mark.asyncio
    async def test_rag_search_empty_query(self, client):
        resp = await client.post(
            "/api/v1/rag/search",
            json={"query": ""},
        )
        assert resp.status_code == 422  # validation error


# ══════════════════════════════════════════════════════════════════════════
# Chat Endpoints
# ══════════════════════════════════════════════════════════════════════════
class TestChatEndpoints:

    @pytest.mark.asyncio
    @patch.object(ClaudeBedrockClient, "converse")
    async def test_chat_basic(self, mock_converse, client):
        mock_converse.return_value = {
            "stopReason": "end_turn",
            "output": {
                "message": {
                    "role": "assistant",
                    "content": [{"text": "Hello! I'm Aria."}],
                }
            },
        }
        resp = await client.post(
            "/api/v1/chat",
            json={"message": "Hello"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "session_id" in data
        assert "response" in data
        assert "I'm Aria" in data["response"]

    @pytest.mark.asyncio
    @patch.object(ClaudeBedrockClient, "converse")
    async def test_chat_session_persistence(self, mock_converse, client):
        """Same session_id should maintain conversation history."""
        mock_converse.return_value = {
            "stopReason": "end_turn",
            "output": {
                "message": {
                    "role": "assistant",
                    "content": [{"text": "Got it."}],
                }
            },
        }
        # First turn
        resp1 = await client.post(
            "/api/v1/chat",
            json={"message": "My name is Alice."},
        )
        session_id = resp1.json()["session_id"]

        # Second turn with same session
        resp2 = await client.post(
            "/api/v1/chat",
            json={"message": "What's my name?", "session_id": session_id},
        )
        assert resp2.json()["message_count"] > resp1.json()["message_count"]

    @pytest.mark.asyncio
    async def test_chat_empty_message(self, client):
        resp = await client.post("/api/v1/chat", json={"message": ""})
        assert resp.status_code == 422


# ══════════════════════════════════════════════════════════════════════════
# Tools Endpoint
# ══════════════════════════════════════════════════════════════════════════
class TestToolsEndpoint:

    @pytest.mark.asyncio
    async def test_list_tools(self, client):
        resp = await client.get("/api/v1/tools")
        assert resp.status_code == 200
        data = resp.json()
        assert data["count"] == 4
        assert "kafka_publish_event" in data["tools"]
        assert "get_account_info" in data["tools"]
        assert "check_network_status" in data["tools"]
        assert "manage_plan" in data["tools"]


# ══════════════════════════════════════════════════════════════════════════
# Kafka Endpoint
# ══════════════════════════════════════════════════════════════════════════
class TestKafkaEndpoint:

    @pytest.mark.asyncio
    async def test_kafka_publish(self, client):
        resp = await client.post(
            "/api/v1/kafka/publish",
            json={
                "topic": "telecom.customer.events",
                "event_type": "TEST",
                "payload": {"test": True},
                "customer_id": "CUST-10001",
            },
        )
        # Should succeed or degrade gracefully
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert "event_id" in data
