"""
tests/conftest.py
──────────────────
Shared pytest fixtures.
"""
from __future__ import annotations

import os
import pytest
from unittest.mock import MagicMock, patch

# Set test environment before any imports
os.environ.setdefault("AWS_ACCESS_KEY_ID", "test_key")
os.environ.setdefault("AWS_SECRET_ACCESS_KEY", "test_secret")
os.environ.setdefault("AWS_REGION", "us-east-1")
os.environ.setdefault("BEDROCK_MODEL_ID", "anthropic.claude-3-5-sonnet-20241022-v2:0")
os.environ.setdefault("ANTHROPIC_API_KEY", "sk-ant-test-key")
os.environ.setdefault("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
os.environ.setdefault("APP_ENV", "test")
os.environ.setdefault("API_SECRET_KEY", "test_secret_key")


@pytest.fixture
def mock_bedrock_client():
    """Return a mock Bedrock client that simulates Claude responses."""
    mock = MagicMock()

    def _make_response(text: str = "Hello from Claude!", stop_reason: str = "end_turn"):
        return {
            "stopReason": stop_reason,
            "output": {
                "message": {
                    "role": "assistant",
                    "content": [{"text": text}],
                }
            },
            "usage": {"inputTokens": 100, "outputTokens": 50},
        }

    mock.converse.return_value = _make_response()
    mock.converse_stream.return_value = {
        "stream": [
            {"contentBlockDelta": {"delta": {"text": "Hello "}}},
            {"contentBlockDelta": {"delta": {"text": "from streaming!"}}},
        ]
    }
    return mock


@pytest.fixture
def mock_tool_response_agent(mock_bedrock_client):
    """Simulate an agent response that first calls a tool, then returns text."""

    def _side_effect(**kwargs):
        messages = kwargs.get("messages", [])
        # If last message contains toolResult, return final text
        last = messages[-1] if messages else {}
        content = last.get("content", [])
        has_tool_result = any("toolResult" in block for block in content)

        if has_tool_result:
            return {
                "stopReason": "end_turn",
                "output": {
                    "message": {
                        "role": "assistant",
                        "content": [{"text": "Your account is active. You are on Unlimited Pro."}],
                    }
                },
            }
        else:
            return {
                "stopReason": "tool_use",
                "output": {
                    "message": {
                        "role": "assistant",
                        "content": [
                            {
                                "toolUse": {
                                    "toolUseId": "tool-001",
                                    "name": "get_account_info",
                                    "input": {"customer_id": "CUST-10001"},
                                }
                            }
                        ],
                    }
                },
            }

    mock_bedrock_client.converse.side_effect = _side_effect
    return mock_bedrock_client


@pytest.fixture
def sample_customer_id():
    return "CUST-10001"


@pytest.fixture
def sample_zip_code():
    return "78701"
