"""
tests/test_rag.py
──────────────────
Tests for the TelecomRAGRetriever.
"""
from __future__ import annotations

import pytest
from src.rag.retriever import TelecomRAGRetriever, Chunk


@pytest.fixture(scope="module")
def retriever():
    return TelecomRAGRetriever()


class TestRetriever:

    def test_index_built(self, retriever):
        assert len(retriever.chunks) > 0

    def test_retrieve_returns_results(self, retriever):
        results = retriever.retrieve("billing payment")
        assert len(results) > 0

    def test_retrieve_top_k(self, retriever):
        results = retriever.retrieve("plan upgrade", top_k=3)
        assert len(results) <= 3

    def test_retrieve_scores_sorted(self, retriever):
        results = retriever.retrieve("unlimited data plan", top_k=5)
        scores = [r["score"] for r in results]
        assert scores == sorted(scores, reverse=True)

    def test_retrieve_billing_query(self, retriever):
        results = retriever.retrieve("autopay discount billing cycle", top_k=3)
        titles = [r["title"] for r in results]
        assert any("Billing" in t or "Plans" in t for t in titles)

    def test_retrieve_network_query(self, retriever):
        results = retriever.retrieve("signal poor no internet restart gateway", top_k=3)
        titles = [r["title"] for r in results]
        assert any("Network" in t or "Troubleshoot" in t for t in titles)

    def test_retrieve_plan_query(self, retriever):
        results = retriever.retrieve("unlimited hotspot international calling", top_k=3)
        assert len(results) > 0

    def test_retrieve_empty_results_on_nonsense(self, retriever):
        """Should still return something (BM25 falls back to low scores)."""
        results = retriever.retrieve("xyzzy frobozz quux", top_k=3)
        assert isinstance(results, list)

    def test_chunk_has_required_fields(self, retriever):
        for chunk in retriever.chunks:
            assert chunk.chunk_id
            assert chunk.doc_id
            assert chunk.title
            assert isinstance(chunk.text, str)
            assert isinstance(chunk.tags, list)

    def test_format_context_non_empty(self, retriever):
        results = retriever.retrieve("billing")
        context = retriever.format_context(results)
        assert len(context) > 0
        assert "[1]" in context

    def test_format_context_empty_input(self, retriever):
        context = retriever.format_context([])
        assert "No relevant" in context

    def test_all_docs_are_indexed(self, retriever):
        """Each knowledge base doc should have at least one chunk."""
        from src.rag.knowledge_base import KNOWLEDGE_BASE_DOCS
        doc_ids_in_chunks = {c.doc_id for c in retriever.chunks}
        for doc in KNOWLEDGE_BASE_DOCS:
            assert doc["doc_id"] in doc_ids_in_chunks

    def test_chunk_overlap_creates_more_chunks(self):
        """A large doc should produce multiple chunks."""
        r = TelecomRAGRetriever()
        long_text = " ".join([f"word{i}" for i in range(2000)])
        chunks = r._chunk_text(long_text, "DOC-X", "Test", [])
        assert len(chunks) > 1

    def test_tokenize_lowercases(self, retriever):
        tokens = retriever._tokenize("Hello World TEST")
        assert all(t == t.lower() for t in tokens)
