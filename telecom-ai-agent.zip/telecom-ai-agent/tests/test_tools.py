"""
tests/test_tools.py
────────────────────
Unit tests for all four tool implementations:
  - get_account_info
  - check_network_status
  - manage_plan
  - kafka_publish_event (mocked)
"""
from __future__ import annotations

import pytest
from unittest.mock import patch, MagicMock

from src.tools.account_tool import get_account_info
from src.tools.network_tool import check_network_status
from src.tools.plan_tool import manage_plan, _CUSTOMER_PLANS
from src.tools import execute_tool


# ══════════════════════════════════════════════════════════════════════════
# Account Tool Tests
# ══════════════════════════════════════════════════════════════════════════
class TestAccountTool:

    def test_lookup_by_customer_id(self, sample_customer_id):
        result = get_account_info(customer_id=sample_customer_id)
        assert result["customer_id"] == sample_customer_id
        assert result["name"] == "Alice Johnson"
        assert result["plan_id"] == "PLAN-UNLIMITED-PRO"

    def test_lookup_by_phone_number(self):
        result = get_account_info(phone_number="+15551001001")
        assert result["customer_id"] == "CUST-10001"
        assert result["name"] == "Alice Johnson"

    def test_lookup_unknown_customer(self):
        result = get_account_info(customer_id="CUST-99999")
        assert "error" in result
        assert "not found" in result["error"]

    def test_lookup_unknown_phone(self):
        result = get_account_info(phone_number="+10000000000")
        assert "error" in result

    def test_no_input_returns_error(self):
        result = get_account_info()
        assert "error" in result

    def test_exclude_usage(self, sample_customer_id):
        result = get_account_info(customer_id=sample_customer_id, include_usage=False)
        assert "data_usage_gb" not in result
        assert "call_minutes_used" not in result

    def test_include_usage_by_default(self, sample_customer_id):
        result = get_account_info(customer_id=sample_customer_id)
        assert "data_usage_gb" in result
        assert "call_minutes_used" in result

    def test_overdue_customer(self):
        result = get_account_info(customer_id="CUST-10002")
        assert result["billing_status"] == "overdue"

    def test_all_mock_customers_loadable(self):
        for cid in ["CUST-10001", "CUST-10002", "CUST-10003"]:
            result = get_account_info(customer_id=cid)
            assert "error" not in result
            assert result["customer_id"] == cid


# ══════════════════════════════════════════════════════════════════════════
# Network Tool Tests
# ══════════════════════════════════════════════════════════════════════════
class TestNetworkTool:

    def test_check_by_zip(self, sample_zip_code):
        result = check_network_status(zip_code=sample_zip_code)
        assert result["zip_code"] == sample_zip_code
        assert "overall_status" in result
        assert "signal_quality" in result

    def test_check_by_customer_id(self, sample_customer_id):
        result = check_network_status(customer_id=sample_customer_id)
        assert "zip_code" in result
        assert result["zip_code"] == "78701"

    def test_outage_detected(self):
        result = check_network_status(zip_code="80201")
        assert result["overall_status"] in ("major_outage", "partial_outage", "degraded")
        assert result["incident_count"] > 0

    def test_no_outage_area(self):
        result = check_network_status(zip_code="98101")
        assert result["overall_status"] == "operational"
        assert result["incident_count"] == 0

    def test_unknown_zip_returns_unknown_signal(self):
        result = check_network_status(zip_code="00000")
        assert result["overall_status"] == "operational"
        assert "4g_lte" in result["signal_quality"]

    def test_no_inputs_returns_error(self):
        result = check_network_status()
        assert "error" in result

    def test_service_type_filter(self):
        result = check_network_status(zip_code="80201", service_type="mobile")
        # Home internet outage should be filtered out
        assert isinstance(result["active_incidents"], list)

    def test_checked_at_timestamp(self, sample_zip_code):
        result = check_network_status(zip_code=sample_zip_code)
        assert "checked_at" in result
        assert "T" in result["checked_at"]  # ISO 8601


# ══════════════════════════════════════════════════════════════════════════
# Plan Tool Tests
# ══════════════════════════════════════════════════════════════════════════
class TestPlanTool:

    def test_list_plans(self):
        result = manage_plan(action="list_plans")
        assert "plans" in result
        assert result["total"] == 4
        plan_ids = [p["plan_id"] for p in result["plans"]]
        assert "PLAN-UNLIMITED-PRO" in plan_ids

    def test_get_plan_details(self):
        result = manage_plan(action="get_plan_details", plan_id="PLAN-BASIC-5G")
        assert result["plan_id"] == "PLAN-BASIC-5G"
        assert result["monthly_cost"] == 35.00

    def test_get_plan_details_unknown(self):
        result = manage_plan(action="get_plan_details", plan_id="PLAN-UNKNOWN")
        assert "error" in result

    def test_get_plan_details_missing_id(self):
        result = manage_plan(action="get_plan_details")
        assert "error" in result

    def test_change_plan_upgrade(self):
        result = manage_plan(
            action="change_plan",
            customer_id="CUST-10002",
            plan_id="PLAN-UNLIMITED-PRO",
        )
        assert result["success"] is True
        assert result["direction"] == "upgrade"
        assert "confirmation_number" in result
        # Restore
        _CUSTOMER_PLANS["CUST-10002"] = "PLAN-BASIC-5G"

    def test_change_plan_downgrade(self):
        result = manage_plan(
            action="change_plan",
            customer_id="CUST-10001",
            plan_id="PLAN-BASIC-5G",
        )
        assert result["success"] is True
        assert result["direction"] == "downgrade"
        # Restore
        _CUSTOMER_PLANS["CUST-10001"] = "PLAN-UNLIMITED-PRO"

    def test_change_plan_unknown_customer(self):
        result = manage_plan(
            action="change_plan",
            customer_id="CUST-99999",
            plan_id="PLAN-BASIC-5G",
        )
        assert "error" in result

    def test_change_plan_unknown_plan(self):
        result = manage_plan(
            action="change_plan",
            customer_id="CUST-10001",
            plan_id="PLAN-FAKE",
        )
        assert "error" in result

    def test_change_plan_missing_customer_id(self):
        result = manage_plan(action="change_plan", plan_id="PLAN-BASIC-5G")
        assert "error" in result

    def test_unknown_action(self):
        result = manage_plan(action="delete_all")
        assert "error" in result


# ══════════════════════════════════════════════════════════════════════════
# Kafka Tool Tests (mocked)
# ══════════════════════════════════════════════════════════════════════════
class TestKafkaTool:

    def test_publish_success(self):
        """Kafka unavailable → should degrade gracefully."""
        from src.tools.kafka_tool import kafka_publish_event
        result = kafka_publish_event(
            topic="telecom.customer.events",
            event_type="TEST_EVENT",
            payload={"key": "value"},
            customer_id="CUST-10001",
        )
        # Either succeeds or degrades – never raises
        assert "event_id" in result
        assert result.get("success") is True

    def test_publish_includes_event_id(self):
        from src.tools.kafka_tool import kafka_publish_event
        result = kafka_publish_event(
            topic="telecom.customer.events",
            event_type="PLAN_CHANGE",
            payload={"plan": "pro"},
        )
        assert "event_id" in result
        assert len(result["event_id"]) == 36  # UUID format

    @patch("src.tools.kafka_tool._get_producer")
    def test_publish_with_mock_producer(self, mock_get_producer):
        """Test with a fully mocked Kafka producer."""
        from src.tools.kafka_tool import kafka_publish_event

        mock_producer = MagicMock()
        mock_future = MagicMock()
        mock_metadata = MagicMock()
        mock_metadata.partition = 0
        mock_metadata.offset = 42
        mock_metadata.topic = "telecom.customer.events"
        mock_future.get.return_value = mock_metadata
        mock_producer.send.return_value = mock_future
        mock_get_producer.return_value = mock_producer

        result = kafka_publish_event(
            topic="telecom.customer.events",
            event_type="SUPPORT_TICKET",
            payload={"issue": "no signal"},
            customer_id="CUST-10001",
        )

        assert result["success"] is True
        assert result["partition"] == 0
        assert result["offset"] == 42
        mock_producer.send.assert_called_once()
        mock_producer.flush.assert_called_once()


# ══════════════════════════════════════════════════════════════════════════
# Tool Dispatcher Tests
# ══════════════════════════════════════════════════════════════════════════
class TestToolDispatcher:

    def test_dispatch_get_account_info(self, sample_customer_id):
        result = execute_tool("get_account_info", {"customer_id": sample_customer_id})
        assert result["customer_id"] == sample_customer_id

    def test_dispatch_check_network(self, sample_zip_code):
        result = execute_tool("check_network_status", {"zip_code": sample_zip_code})
        assert "overall_status" in result

    def test_dispatch_manage_plan(self):
        result = execute_tool("manage_plan", {"action": "list_plans"})
        assert "plans" in result

    def test_dispatch_unknown_tool(self):
        result = execute_tool("nonexistent_tool", {})
        assert "error" in result

    def test_dispatch_tool_with_bad_args(self):
        # manage_plan with invalid action – should return error, not raise
        result = execute_tool("manage_plan", {"action": "explode"})
        assert "error" in result
