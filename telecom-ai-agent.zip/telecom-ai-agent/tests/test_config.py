"""
tests/test_config.py
─────────────────────
Tests for application configuration loading.
"""
import os
import pytest
from unittest.mock import patch


class TestSettings:

    def test_settings_load(self):
        from src.config import get_settings
        settings = get_settings()
        assert settings.aws_region == "us-east-1"
        assert settings.app_port == 8000

    def test_origins_list(self):
        from src.config import Settings
        s = Settings(ALLOWED_ORIGINS="http://localhost:3000,http://localhost:8000")
        assert "http://localhost:3000" in s.origins_list
        assert "http://localhost:8000" in s.origins_list

    def test_is_production_false_in_test(self):
        from src.config import Settings
        s = Settings(APP_ENV="test")
        assert s.is_production is False

    def test_is_production_true(self):
        from src.config import Settings
        s = Settings(APP_ENV="production")
        assert s.is_production is True

    def test_settings_are_cached(self):
        from src.config import get_settings
        s1 = get_settings()
        s2 = get_settings()
        assert s1 is s2  # lru_cache returns same object
