"""
src/config.py
─────────────
Centralised configuration using Pydantic-Settings.
All values are read from the .env file (or environment variables).
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── AWS / Bedrock ──────────────────────────────────────────────────────
    aws_access_key_id: str = Field(default="", alias="AWS_ACCESS_KEY_ID")
    aws_secret_access_key: str = Field(default="", alias="AWS_SECRET_ACCESS_KEY")
    aws_region: str = Field(default="us-east-1", alias="AWS_REGION")
    bedrock_model_id: str = Field(
        default="anthropic.claude-3-5-sonnet-20241022-v2:0",
        alias="BEDROCK_MODEL_ID",
    )

    # ── Anthropic Direct ───────────────────────────────────────────────────
    anthropic_api_key: str = Field(default="", alias="ANTHROPIC_API_KEY")

    # ── Kafka ──────────────────────────────────────────────────────────────
    kafka_bootstrap_servers: str = Field(
        default="localhost:9092", alias="KAFKA_BOOTSTRAP_SERVERS"
    )
    kafka_topic_events: str = Field(
        default="telecom.customer.events", alias="KAFKA_TOPIC_EVENTS"
    )
    kafka_topic_alerts: str = Field(
        default="telecom.network.alerts", alias="KAFKA_TOPIC_ALERTS"
    )
    kafka_consumer_group: str = Field(
        default="telecom-ai-agent", alias="KAFKA_CONSUMER_GROUP"
    )
    kafka_auto_offset_reset: str = Field(
        default="earliest", alias="KAFKA_AUTO_OFFSET_RESET"
    )

    # ── Application ────────────────────────────────────────────────────────
    app_name: str = Field(default="NovaTel AI Assistant", alias="APP_NAME")
    app_env: str = Field(default="development", alias="APP_ENV")
    app_host: str = Field(default="0.0.0.0", alias="APP_HOST")
    app_port: int = Field(default=8000, alias="APP_PORT")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")

    # ── RAG ────────────────────────────────────────────────────────────────
    embedding_model: str = Field(
        default="amazon.titan-embed-text-v1", alias="EMBEDDING_MODEL"
    )
    chunk_size: int = Field(default=512, alias="CHUNK_SIZE")
    chunk_overlap: int = Field(default=50, alias="CHUNK_OVERLAP")
    top_k_results: int = Field(default=5, alias="TOP_K_RESULTS")

    # ── Security ───────────────────────────────────────────────────────────
    api_secret_key: str = Field(
        default="dev_secret", alias="API_SECRET_KEY"
    )
    allowed_origins: str = Field(
        default="http://localhost:3000", alias="ALLOWED_ORIGINS"
    )

    @property
    def origins_list(self) -> list[str]:
        return [o.strip() for o in self.allowed_origins.split(",")]

    @property
    def is_production(self) -> bool:
        return self.app_env.lower() == "production"


@lru_cache
def get_settings() -> Settings:
    return Settings()
