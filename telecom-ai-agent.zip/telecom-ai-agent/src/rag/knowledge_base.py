"""
src/rag/knowledge_base.py
──────────────────────────
In-memory knowledge base for NovaTel.
Implements the chunking + BM25 + embedding hybrid retrieval
pattern from the Anthropic "Claude in Amazon Bedrock" course.
"""
from __future__ import annotations

KNOWLEDGE_BASE_DOCS: list[dict] = [
    {
        "doc_id": "KB-001",
        "title": "NovaTel Billing FAQ",
        "content": """
NovaTel bills customers on a monthly cycle. Your billing date is the same day each month
as your activation date. Bills are available in the My NovaTel app and online portal 7 days
before the due date.

Payment methods accepted: credit card, debit card, bank transfer (ACH), and autopay.
Autopay customers receive a $5/month discount on any plan.

Late payments incur a $10 fee after a 10-day grace period. Accounts more than 30 days
overdue may have services suspended. To avoid suspension, contact NovaTel billing support
at 1-800-NOVOTEL or use the in-app chat.

Disputes must be filed within 60 days of the statement date.
Itemised billing is available on request at no extra charge.
""",
        "tags": ["billing", "payment", "invoice", "dispute"],
    },
    {
        "doc_id": "KB-002",
        "title": "NovaTel Plans Overview",
        "content": """
NovaTel offers four main consumer and business plans:

1. Basic 5G ($35/mo): 5 GB data, unlimited calls & SMS. Ideal for light users.
2. Standard 5G ($55/mo): 20 GB data, 10 GB hotspot, includes Apple TV+.
3. Unlimited Pro ($75/mo): Unlimited data, 50 GB hotspot, international calling, Apple TV+ & Apple Music.
4. Business Elite ($150/mo): Unlimited data, 100 GB hotspot, SLA guarantee, Microsoft 365 Basic, 12-month contract.

All plans include:
- 5G nationwide coverage
- Wi-Fi calling
- Voicemail and caller ID
- Free SIM card replacement

Add-ons available: international data passes ($10/day), device insurance ($8/mo), 
cloud storage bundles ($5/mo for 200 GB).
""",
        "tags": ["plans", "pricing", "features", "5G"],
    },
    {
        "doc_id": "KB-003",
        "title": "Network Troubleshooting Guide",
        "content": """
If you are experiencing poor signal or no service, try these steps:

1. Toggle airplane mode off and on.
2. Restart your device.
3. Check for outages at novotel.com/status or ask Aria.
4. Ensure your SIM card is properly seated.
5. Reset network settings (Settings > General > Reset Network Settings on iPhone).
6. Move to an area with less obstruction (buildings, trees can block 5G mmWave).

For home internet issues:
1. Restart your NovaTel gateway (unplug 30 seconds, replug).
2. Check all cable connections.
3. Check for local outages.
4. Run a speed test at novotel.com/speedtest.
5. Contact support if issue persists after 30 minutes.

5G mmWave operates at high frequency and has limited range (~250m, line of sight).
5G Sub-6 has broader coverage and better building penetration.
""",
        "tags": ["network", "troubleshooting", "signal", "5G", "internet"],
    },
    {
        "doc_id": "KB-004",
        "title": "Porting Your Number to NovaTel",
        "content": """
You can bring your existing phone number to NovaTel (number portability).

Requirements:
- Your current account must be active (do NOT cancel before porting).
- You need your current account number and PIN/passcode from your old carrier.
- The name on the NovaTel account must match the name on your old account.

Process:
1. Activate a new NovaTel plan.
2. Submit a port request in the My NovaTel app or store.
3. Porting typically completes within 1-3 business hours but can take up to 24 hours.
4. Your old service ends automatically once porting is complete.

Domestic number porting is free. International porting is not supported.
If your port fails, contact support within 24 hours.
""",
        "tags": ["porting", "number transfer", "activation"],
    },
    {
        "doc_id": "KB-005",
        "title": "International Roaming",
        "content": """
NovaTel Unlimited Pro and Business Elite plans include calls and texts to Canada and Mexico.
Data roaming requires an International Data Pass.

International Data Passes:
- Daily Pass: $10/day, 512 MB high-speed data in 100+ countries.
- Weekly Pass: $50/week, 2 GB high-speed data.
- Monthly Pass: $150/month, 8 GB high-speed data.

After the high-speed data allowance is exhausted, speeds are reduced to 128 kbps.
Emergency calls (911 equivalent) are always free internationally.

Wi-Fi calling and texting are available without an international pass when connected
to Wi-Fi, using your regular plan minutes and messages.

To activate roaming: Settings > Cellular > Roaming > Enable Data Roaming.
""",
        "tags": ["roaming", "international", "travel", "data"],
    },
]
