"""
src/rag/retriever.py
─────────────────────
Hybrid RAG retriever implementing:
  1. Text chunking (with overlap)
  2. BM25 sparse retrieval
  3. TF-IDF vector similarity (replaces Bedrock embeddings in local/test mode)
  4. Reciprocal Rank Fusion for hybrid scoring

Follows the RAG pipeline pattern from the Anthropic Bedrock course.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

import numpy as np
from rank_bm25 import BM25Okapi  # type: ignore
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from src.rag.knowledge_base import KNOWLEDGE_BASE_DOCS
from src.config import get_settings
from src.logger import get_logger

logger = get_logger(__name__)


@dataclass
class Chunk:
    chunk_id: str
    doc_id: str
    title: str
    text: str
    tags: list[str]
    chunk_index: int


class TelecomRAGRetriever:
    """
    Hybrid BM25 + TF-IDF retriever over the NovaTel knowledge base.
    """

    def __init__(self) -> None:
        self.settings = get_settings()
        self.chunks: list[Chunk] = []
        self._bm25: BM25Okapi | None = None
        self._tfidf: TfidfVectorizer | None = None
        self._tfidf_matrix = None
        self._build_index()

    # ── Index construction ────────────────────────────────────────────────
    def _build_index(self) -> None:
        """Chunk documents and build BM25 + TF-IDF indexes."""
        for doc in KNOWLEDGE_BASE_DOCS:
            doc_chunks = self._chunk_text(
                text=doc["content"],
                doc_id=doc["doc_id"],
                title=doc["title"],
                tags=doc.get("tags", []),
            )
            self.chunks.extend(doc_chunks)

        tokenized = [self._tokenize(c.text) for c in self.chunks]
        self._bm25 = BM25Okapi(tokenized)

        texts = [c.text for c in self.chunks]
        self._tfidf = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        self._tfidf_matrix = self._tfidf.fit_transform(texts)

        logger.info(
            "rag_index_built",
            docs=len(KNOWLEDGE_BASE_DOCS),
            chunks=len(self.chunks),
        )

    def _chunk_text(
        self,
        text: str,
        doc_id: str,
        title: str,
        tags: list[str],
    ) -> list[Chunk]:
        """Split text into overlapping chunks."""
        size = self.settings.chunk_size
        overlap = self.settings.chunk_overlap
        words = text.split()
        chunks: list[Chunk] = []
        idx = 0
        chunk_index = 0

        while idx < len(words):
            chunk_words = words[idx : idx + size]
            chunk_text = " ".join(chunk_words).strip()
            if chunk_text:
                chunks.append(
                    Chunk(
                        chunk_id=f"{doc_id}-{chunk_index}",
                        doc_id=doc_id,
                        title=title,
                        text=chunk_text,
                        tags=tags,
                        chunk_index=chunk_index,
                    )
                )
                chunk_index += 1
            idx += size - overlap

        return chunks

    @staticmethod
    def _tokenize(text: str) -> list[str]:
        return re.findall(r"\b\w+\b", text.lower())

    # ── Retrieval ─────────────────────────────────────────────────────────
    def retrieve(self, query: str, top_k: int | None = None) -> list[dict[str, Any]]:
        """
        Hybrid BM25 + TF-IDF retrieval with Reciprocal Rank Fusion.
        Returns top_k ranked chunks.
        """
        k = top_k or self.settings.top_k_results
        n = len(self.chunks)
        if n == 0:
            return []

        # BM25 scores
        tokenized_query = self._tokenize(query)
        bm25_scores = self._bm25.get_scores(tokenized_query)
        bm25_ranks = np.argsort(-bm25_scores)

        # TF-IDF cosine similarity
        query_vec = self._tfidf.transform([query])
        cos_scores = cosine_similarity(query_vec, self._tfidf_matrix).flatten()
        tfidf_ranks = np.argsort(-cos_scores)

        # Reciprocal Rank Fusion (RRF)
        rrf_constant = 60
        rrf_scores = np.zeros(n)
        for rank, idx in enumerate(bm25_ranks):
            rrf_scores[idx] += 1.0 / (rrf_constant + rank + 1)
        for rank, idx in enumerate(tfidf_ranks):
            rrf_scores[idx] += 1.0 / (rrf_constant + rank + 1)

        top_indices = np.argsort(-rrf_scores)[:k]

        results = []
        for idx in top_indices:
            chunk = self.chunks[idx]
            results.append(
                {
                    "chunk_id": chunk.chunk_id,
                    "doc_id": chunk.doc_id,
                    "title": chunk.title,
                    "text": chunk.text,
                    "tags": chunk.tags,
                    "score": float(rrf_scores[idx]),
                }
            )

        logger.debug("rag_retrieved", query=query[:60], results=len(results))
        return results

    def format_context(self, results: list[dict[str, Any]]) -> str:
        """Format retrieved chunks into a context string for Claude."""
        if not results:
            return "No relevant knowledge base articles found."

        parts = []
        for i, r in enumerate(results, 1):
            parts.append(
                f"[{i}] {r['title']} (ID: {r['doc_id']})\n{r['text']}"
            )
        return "\n\n---\n\n".join(parts)
