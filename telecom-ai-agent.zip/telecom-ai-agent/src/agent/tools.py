"""
src/agent/tools.py
───────────────────
JSON-Schema tool definitions passed to Claude via Bedrock.
Four tools:
  1. kafka_publish_event      – publish a customer event to Kafka
  2. get_account_info         – look up a telecom customer account
  3. check_network_status     – query network / outage diagnostics
  4. manage_plan              – list, upgrade, or downgrade telecom plans
"""

TOOLS: list[dict] = [
    # ── 1. Kafka Event Publisher ──────────────────────────────────────────
    {
        "toolSpec": {
            "name": "kafka_publish_event",
            "description": (
                "Publishes a structured customer or network event to the Kafka "
                "event bus. Use this to log support interactions, flag anomalies, "
                "trigger downstream workflows, or raise billing alerts."
            ),
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "topic": {
                            "type": "string",
                            "enum": [
                                "telecom.customer.events",
                                "telecom.network.alerts",
                                "telecom.billing.events",
                            ],
                            "description": "Target Kafka topic.",
                        },
                        "event_type": {
                            "type": "string",
                            "description": (
                                "Type of event, e.g. 'SUPPORT_TICKET_CREATED', "
                                "'PLAN_CHANGE_REQUESTED', 'NETWORK_OUTAGE_DETECTED'."
                            ),
                        },
                        "payload": {
                            "type": "object",
                            "description": "Free-form JSON payload for the event.",
                        },
                        "customer_id": {
                            "type": "string",
                            "description": "Optional customer identifier to tag the event.",
                        },
                    },
                    "required": ["topic", "event_type", "payload"],
                }
            },
        }
    },
    # ── 2. Account Lookup ─────────────────────────────────────────────────
    {
        "toolSpec": {
            "name": "get_account_info",
            "description": (
                "Retrieves a NovaTel customer's account details including their "
                "name, current plan, data usage, billing status, and active services. "
                "Call this before discussing billing or plan changes."
            ),
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "customer_id": {
                            "type": "string",
                            "description": "The unique customer account ID (e.g. 'CUST-12345').",
                        },
                        "phone_number": {
                            "type": "string",
                            "description": "Alternatively look up by phone number (e.g. '+15551234567').",
                        },
                        "include_usage": {
                            "type": "boolean",
                            "description": "If true, include current billing cycle usage stats.",
                            "default": True,
                        },
                    },
                    "required": [],
                }
            },
        }
    },
    # ── 3. Network Diagnostics ────────────────────────────────────────────
    {
        "toolSpec": {
            "name": "check_network_status",
            "description": (
                "Checks real-time network status and known outages for a given "
                "area or cell tower. Returns signal quality, active incidents, "
                "estimated resolution time, and maintenance windows."
            ),
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "zip_code": {
                            "type": "string",
                            "description": "5-digit US ZIP code for the area to check.",
                        },
                        "customer_id": {
                            "type": "string",
                            "description": "Customer ID to auto-resolve their service address.",
                        },
                        "service_type": {
                            "type": "string",
                            "enum": ["mobile", "home_internet", "business", "all"],
                            "description": "Type of service to check.",
                            "default": "all",
                        },
                    },
                    "required": [],
                }
            },
        }
    },
    # ── 4. Plan Management ────────────────────────────────────────────────
    {
        "toolSpec": {
            "name": "manage_plan",
            "description": (
                "Lists available NovaTel service plans or processes a plan "
                "change (upgrade/downgrade) for a customer. Always call "
                "get_account_info first to confirm the customer's current plan."
            ),
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": ["list_plans", "change_plan", "get_plan_details"],
                            "description": "Action to perform.",
                        },
                        "customer_id": {
                            "type": "string",
                            "description": "Required for 'change_plan'.",
                        },
                        "plan_id": {
                            "type": "string",
                            "description": "Target plan ID for 'change_plan' or 'get_plan_details'.",
                        },
                        "effective_date": {
                            "type": "string",
                            "description": "ISO 8601 date for when the change takes effect. Defaults to next billing cycle.",
                        },
                    },
                    "required": ["action"],
                }
            },
        }
    },
]

TOOL_NAMES = {t["toolSpec"]["name"] for t in TOOLS}
