"""
src/agent/claude_client.py
───────────────────────────
Thin wrapper around the AWS Bedrock Converse API for Claude.
Supports:
  • Single-turn & multi-turn conversations
  • Streaming responses
  • Tool / function calling
  • System prompts
  • Retry logic with exponential back-off
"""
from __future__ import annotations

import json
from typing import Any, Generator

import boto3
from botocore.config import Config
from tenacity import retry, stop_after_attempt, wait_exponential

from src.config import get_settings
from src.logger import get_logger

logger = get_logger(__name__)


class ClaudeBedrockClient:
    """AWS Bedrock Converse API client for Claude."""

    def __init__(self) -> None:
        self.settings = get_settings()
        self._client = self._build_client()

    # ── Factory ───────────────────────────────────────────────────────────
    def _build_client(self):
        cfg = Config(
            region_name=self.settings.aws_region,
            retries={"max_attempts": 3, "mode": "adaptive"},
        )
        return boto3.client(
            service_name="bedrock-runtime",
            region_name=self.settings.aws_region,
            aws_access_key_id=self.settings.aws_access_key_id or None,
            aws_secret_access_key=self.settings.aws_secret_access_key or None,
            config=cfg,
        )

    # ── Core call ─────────────────────────────────────────────────────────
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        reraise=True,
    )
    def converse(
        self,
        messages: list[dict],
        system_prompt: str | None = None,
        tools: list[dict] | None = None,
        tool_choice: dict | None = None,
        max_tokens: int = 4096,
        temperature: float = 0.5,
    ) -> dict:
        """
        Send messages to Claude via Bedrock Converse API.

        Returns the raw Bedrock response dict.
        """
        payload: dict[str, Any] = {
            "modelId": self.settings.bedrock_model_id,
            "messages": messages,
            "inferenceConfig": {
                "maxTokens": max_tokens,
                "temperature": temperature,
            },
        }

        if system_prompt:
            payload["system"] = [{"text": system_prompt}]

        if tools:
            payload["toolConfig"] = {"tools": tools}
            if tool_choice:
                payload["toolConfig"]["toolChoice"] = tool_choice

        logger.debug(
            "bedrock_converse",
            model=self.settings.bedrock_model_id,
            message_count=len(messages),
            has_tools=bool(tools),
        )

        response = self._client.converse(**payload)
        logger.debug("bedrock_response", stop_reason=response.get("stopReason"))
        return response

    # ── Streaming ─────────────────────────────────────────────────────────
    def converse_stream(
        self,
        messages: list[dict],
        system_prompt: str | None = None,
        max_tokens: int = 4096,
        temperature: float = 0.5,
    ) -> Generator[str, None, None]:
        """Yield text chunks as they arrive (streaming)."""
        payload: dict[str, Any] = {
            "modelId": self.settings.bedrock_model_id,
            "messages": messages,
            "inferenceConfig": {
                "maxTokens": max_tokens,
                "temperature": temperature,
            },
        }
        if system_prompt:
            payload["system"] = [{"text": system_prompt}]

        response = self._client.converse_stream(**payload)
        for event in response["stream"]:
            if "contentBlockDelta" in event:
                delta = event["contentBlockDelta"]["delta"]
                if "text" in delta:
                    yield delta["text"]

    # ── Helpers ───────────────────────────────────────────────────────────
    @staticmethod
    def extract_text(response: dict) -> str:
        """Pull plain text from a Converse response."""
        for block in response.get("output", {}).get("message", {}).get("content", []):
            if block.get("type") == "text" or "text" in block:
                return block.get("text", "")
        return ""

    @staticmethod
    def extract_tool_use(response: dict) -> list[dict]:
        """Return list of tool-use blocks from a Converse response."""
        tool_uses = []
        for block in response.get("output", {}).get("message", {}).get("content", []):
            if block.get("type") == "toolUse" or "toolUse" in block:
                tool_uses.append(block.get("toolUse", block))
        return tool_uses

    @staticmethod
    def build_user_message(text: str) -> dict:
        return {"role": "user", "content": [{"text": text}]}

    @staticmethod
    def build_assistant_message(response: dict) -> dict:
        """Convert a Bedrock response into an assistant history entry."""
        content = (
            response.get("output", {}).get("message", {}).get("content", [])
        )
        return {"role": "assistant", "content": content}

    @staticmethod
    def build_tool_result_message(tool_use_id: str, result: Any) -> dict:
        """Wrap a tool result so it can be appended to conversation history."""
        return {
            "role": "user",
            "content": [
                {
                    "toolResult": {
                        "toolUseId": tool_use_id,
                        "content": [{"text": json.dumps(result)}],
                    }
                }
            ],
        }
