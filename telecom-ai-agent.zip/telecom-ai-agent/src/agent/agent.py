"""
src/agent/agent.py
───────────────────
NovaTel Agentic Chat – multi-turn agentic loop with tool use.

The agent:
  1. Receives user messages
  2. Sends them to Claude via Bedrock Converse API (with tools)
  3. Executes any tool calls Claude requests
  4. Feeds results back to Claude
  5. Repeats until Claude provides a final text response
  6. Publishes support events to Kafka

This follows the agentic loop pattern taught in the Anthropic
"Claude in Amazon Bedrock" course.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Generator

from src.agent.claude_client import ClaudeBedrockClient
from src.agent.tools import TOOLS
from src.tools import execute_tool
from src.tools.kafka_tool import kafka_publish_event
from src.config import get_settings
from src.logger import get_logger

logger = get_logger(__name__)

SYSTEM_PROMPT = """You are Aria, the intelligent virtual assistant for NovaTel — a leading telecommunications company.

Your role is to help customers with:
• Account enquiries (billing, usage, payments)
• Plan changes (upgrades, downgrades, comparisons)
• Network issues (outages, signal quality, troubleshooting)
• General telecom support

Guidelines:
- Be warm, concise, and professional. Use plain English – avoid jargon.
- Always look up the customer's account before discussing billing or plan changes.
- If there is a network outage affecting the customer, proactively mention it and provide the ETA.
- After resolving an issue or changing a plan, publish a Kafka event to log the interaction.
- Never fabricate account data. If you don't know something, say so and offer to escalate.
- Use tools in a logical sequence: account info → network check → plan action → Kafka event.

You have access to four tools:
1. get_account_info        – look up customer account details
2. check_network_status    – check network status and outages
3. manage_plan             – list, compare, and change service plans
4. kafka_publish_event     – publish events to the NovaTel event bus

Today's date: {today}
"""


@dataclass
class ChatSession:
    """Holds the full conversation history for a single chat session."""
    session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    customer_id: str | None = None
    messages: list[dict] = field(default_factory=list)
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    tool_call_count: int = 0
    max_tool_iterations: int = 10


class TelecomAgent:
    """
    Agentic chat loop for NovaTel customer support.

    Usage:
        agent = TelecomAgent()
        session = agent.new_session(customer_id="CUST-10001")
        response = agent.chat(session, "I need to upgrade my plan")
    """

    def __init__(self) -> None:
        self.client = ClaudeBedrockClient()
        self.settings = get_settings()

    # ── Session management ────────────────────────────────────────────────
    @staticmethod
    def new_session(customer_id: str | None = None) -> ChatSession:
        session = ChatSession(customer_id=customer_id)
        logger.info(
            "session_created",
            session_id=session.session_id,
            customer_id=customer_id,
        )
        return session

    # ── Main agentic loop ─────────────────────────────────────────────────
    def chat(
        self,
        session: ChatSession,
        user_message: str,
    ) -> str:
        """
        Process a user message and return the final text response.
        Runs the full agentic loop internally (tool calls → results → reply).
        """
        # Append user message to history
        session.messages.append(
            self.client.build_user_message(user_message)
        )

        system = SYSTEM_PROMPT.format(
            today=datetime.now(timezone.utc).strftime("%Y-%m-%d")
        )

        # Agentic loop
        iterations = 0
        while iterations < session.max_tool_iterations:
            iterations += 1

            response = self.client.converse(
                messages=session.messages,
                system_prompt=system,
                tools=TOOLS,
                max_tokens=4096,
            )

            stop_reason = response.get("stopReason", "")
            assistant_msg = self.client.build_assistant_message(response)
            session.messages.append(assistant_msg)

            # Final text response
            if stop_reason == "end_turn":
                final_text = self.client.extract_text(response)
                self._publish_interaction_event(session, user_message, final_text)
                logger.info(
                    "agent_response",
                    session_id=session.session_id,
                    iterations=iterations,
                    stop_reason=stop_reason,
                )
                return final_text

            # Tool use requested
            if stop_reason == "tool_use":
                tool_uses = self.client.extract_tool_use(response)
                session.tool_call_count += len(tool_uses)

                for tool_use in tool_uses:
                    tool_name = tool_use.get("name")
                    tool_input = tool_use.get("input", {})
                    tool_use_id = tool_use.get("toolUseId", str(uuid.uuid4()))

                    logger.info(
                        "tool_call",
                        session_id=session.session_id,
                        tool=tool_name,
                        use_id=tool_use_id,
                    )

                    result = execute_tool(tool_name, tool_input)

                    # Append tool result to history
                    session.messages.append(
                        self.client.build_tool_result_message(tool_use_id, result)
                    )

                continue  # let Claude react to tool results

            # Unexpected stop
            logger.warning(
                "unexpected_stop_reason",
                stop_reason=stop_reason,
                session_id=session.session_id,
            )
            break

        return "I'm sorry, I was unable to complete the request. Please try again or contact support."

    # ── Streaming variant ─────────────────────────────────────────────────
    def chat_stream(
        self,
        session: ChatSession,
        user_message: str,
    ) -> Generator[str, None, None]:
        """
        Stream the assistant response token-by-token (no tool use in streaming mode).
        """
        session.messages.append(self.client.build_user_message(user_message))
        system = SYSTEM_PROMPT.format(
            today=datetime.now(timezone.utc).strftime("%Y-%m-%d")
        )
        yield from self.client.converse_stream(
            messages=session.messages,
            system_prompt=system,
        )

    # ── Private helpers ───────────────────────────────────────────────────
    def _publish_interaction_event(
        self,
        session: ChatSession,
        user_message: str,
        agent_response: str,
    ) -> None:
        """Publish a support interaction event to Kafka (best-effort)."""
        try:
            kafka_publish_event(
                topic=self.settings.kafka_topic_events,
                event_type="SUPPORT_INTERACTION_COMPLETED",
                customer_id=session.customer_id,
                payload={
                    "session_id": session.session_id,
                    "user_message_preview": user_message[:120],
                    "agent_response_preview": agent_response[:120],
                    "tool_calls": session.tool_call_count,
                    "message_count": len(session.messages),
                },
            )
        except Exception as exc:
            logger.warning("kafka_interaction_publish_failed", error=str(exc))
