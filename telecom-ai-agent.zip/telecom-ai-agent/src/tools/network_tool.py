"""
src/tools/network_tool.py
──────────────────────────
Network status and outage diagnostics tool for NovaTel.
Returns real-time (mocked) network health data by ZIP code or customer ID.
"""
from __future__ import annotations

from datetime import datetime, timezone, timedelta
from typing import Any

from src.tools.account_tool import get_account_info
from src.logger import get_logger

logger = get_logger(__name__)

# ── Mock network incident database ────────────────────────────────────────
_MOCK_INCIDENTS: dict[str, list[dict]] = {
    "78701": [
        {
            "incident_id": "INC-2025-0441",
            "type": "PLANNED_MAINTENANCE",
            "service": "mobile",
            "severity": "low",
            "title": "5G tower firmware upgrade",
            "description": "Scheduled maintenance on towers in downtown Austin.",
            "started_at": "2025-02-25T02:00:00Z",
            "estimated_resolution": "2025-02-25T06:00:00Z",
            "status": "in_progress",
            "affected_services": ["5G data"],
        }
    ],
    "80201": [
        {
            "incident_id": "INC-2025-0398",
            "type": "UNPLANNED_OUTAGE",
            "service": "home_internet",
            "severity": "high",
            "title": "Fiber cable damage – Denver north corridor",
            "description": "Excavation work caused a fiber cut affecting ~1,200 customers.",
            "started_at": "2025-02-24T14:30:00Z",
            "estimated_resolution": "2025-02-25T20:00:00Z",
            "status": "under_repair",
            "affected_services": ["home internet", "business broadband"],
        }
    ],
    "98101": [],  # No incidents
}

_MOCK_SIGNAL: dict[str, dict] = {
    "78701": {"4g_lte": "excellent", "5g": "good", "home_internet": "excellent"},
    "80201": {"4g_lte": "good", "5g": "fair", "home_internet": "degraded"},
    "98101": {"4g_lte": "excellent", "5g": "excellent", "home_internet": "excellent"},
}

_DEFAULT_SIGNAL = {"4g_lte": "unknown", "5g": "unknown", "home_internet": "unknown"}
_DEFAULT_INCIDENTS: list[dict] = []


def check_network_status(
    zip_code: str | None = None,
    customer_id: str | None = None,
    service_type: str = "all",
) -> dict[str, Any]:
    """
    Return network health for the specified area.
    Resolves ZIP from customer account if customer_id provided.
    """
    if not zip_code and customer_id:
        account = get_account_info(customer_id=customer_id, include_usage=False)
        if "error" not in account:
            zip_code = account.get("address", {}).get("zip")

    if not zip_code:
        return {"error": "Provide zip_code or a valid customer_id."}

    incidents = _MOCK_INCIDENTS.get(zip_code, _DEFAULT_INCIDENTS)
    signal = _MOCK_SIGNAL.get(zip_code, _DEFAULT_SIGNAL)

    # Filter by service_type
    if service_type != "all":
        incidents = [i for i in incidents if i.get("service") == service_type]
        signal = {k: v for k, v in signal.items() if service_type in k}

    overall = "operational"
    if any(i["severity"] == "high" for i in incidents):
        overall = "major_outage"
    elif any(i["severity"] == "medium" for i in incidents):
        overall = "partial_outage"
    elif incidents:
        overall = "degraded"

    result = {
        "zip_code": zip_code,
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "overall_status": overall,
        "signal_quality": signal,
        "active_incidents": incidents,
        "incident_count": len(incidents),
        "next_maintenance_window": "2025-02-27T02:00:00Z" if zip_code == "78701" else None,
    }

    logger.info(
        "network_status_checked",
        zip_code=zip_code,
        overall=overall,
        incidents=len(incidents),
    )
    return result
