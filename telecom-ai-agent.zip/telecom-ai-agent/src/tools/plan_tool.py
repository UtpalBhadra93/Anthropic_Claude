"""
src/tools/plan_tool.py
───────────────────────
Plan management tool – list available NovaTel plans and process
plan changes for customers.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from src.logger import get_logger

logger = get_logger(__name__)

# ── Plan catalog ───────────────────────────────────────────────────────────
_PLANS: dict[str, dict] = {
    "PLAN-BASIC-5G": {
        "plan_id": "PLAN-BASIC-5G",
        "name": "Basic 5G",
        "monthly_cost": 35.00,
        "data_gb": 5,
        "unlimited_calls": True,
        "unlimited_sms": True,
        "hotspot_gb": 0,
        "international_calling": False,
        "streaming_perks": [],
        "description": "Affordable 5G plan with 5 GB data for light users.",
        "contract_months": 0,
        "category": "consumer",
    },
    "PLAN-STANDARD-5G": {
        "plan_id": "PLAN-STANDARD-5G",
        "name": "Standard 5G",
        "monthly_cost": 55.00,
        "data_gb": 20,
        "unlimited_calls": True,
        "unlimited_sms": True,
        "hotspot_gb": 10,
        "international_calling": False,
        "streaming_perks": ["Apple TV+"],
        "description": "20 GB data with hotspot – great for everyday users.",
        "contract_months": 0,
        "category": "consumer",
    },
    "PLAN-UNLIMITED-PRO": {
        "plan_id": "PLAN-UNLIMITED-PRO",
        "name": "Unlimited Pro",
        "monthly_cost": 75.00,
        "data_gb": None,  # Unlimited
        "unlimited_calls": True,
        "unlimited_sms": True,
        "hotspot_gb": 50,
        "international_calling": True,
        "streaming_perks": ["Apple TV+", "Apple Music"],
        "description": "Unlimited data, 50 GB hotspot, and international calling.",
        "contract_months": 0,
        "category": "consumer",
    },
    "PLAN-BUSINESS-ELITE": {
        "plan_id": "PLAN-BUSINESS-ELITE",
        "name": "Business Elite",
        "monthly_cost": 150.00,
        "data_gb": None,
        "unlimited_calls": True,
        "unlimited_sms": True,
        "hotspot_gb": 100,
        "international_calling": True,
        "streaming_perks": ["Apple TV+", "Apple Music", "Microsoft 365 Basic"],
        "description": "Enterprise-grade plan with SLA, priority data and collaboration tools.",
        "contract_months": 12,
        "category": "business",
    },
}

# ── Simulated customer plan store ──────────────────────────────────────────
_CUSTOMER_PLANS: dict[str, str] = {
    "CUST-10001": "PLAN-UNLIMITED-PRO",
    "CUST-10002": "PLAN-BASIC-5G",
    "CUST-10003": "PLAN-BUSINESS-ELITE",
}


def manage_plan(
    action: str,
    customer_id: str | None = None,
    plan_id: str | None = None,
    effective_date: str | None = None,
) -> dict[str, Any]:
    """
    Manage NovaTel service plans.

    Actions:
        list_plans        – return all available plans
        get_plan_details  – return details for a specific plan_id
        change_plan       – change a customer's plan
    """
    if action == "list_plans":
        return {
            "plans": list(_PLANS.values()),
            "total": len(_PLANS),
        }

    elif action == "get_plan_details":
        if not plan_id:
            return {"error": "plan_id is required for get_plan_details."}
        plan = _PLANS.get(plan_id)
        if not plan:
            return {"error": f"Plan '{plan_id}' not found.", "available_plans": list(_PLANS.keys())}
        return plan

    elif action == "change_plan":
        if not customer_id:
            return {"error": "customer_id is required for change_plan."}
        if not plan_id:
            return {"error": "plan_id is required for change_plan."}

        current_plan_id = _CUSTOMER_PLANS.get(customer_id)
        if not current_plan_id:
            return {"error": f"No plan found for customer {customer_id}."}

        new_plan = _PLANS.get(plan_id)
        if not new_plan:
            return {"error": f"Plan '{plan_id}' does not exist.", "available_plans": list(_PLANS.keys())}

        current_plan = _PLANS[current_plan_id]

        if not effective_date:
            effective_date = "next_billing_cycle"

        # Commit the change in our mock store
        _CUSTOMER_PLANS[customer_id] = plan_id

        direction = (
            "upgrade"
            if new_plan["monthly_cost"] > current_plan["monthly_cost"]
            else "downgrade"
            if new_plan["monthly_cost"] < current_plan["monthly_cost"]
            else "lateral_change"
        )

        logger.info(
            "plan_changed",
            customer_id=customer_id,
            old_plan=current_plan_id,
            new_plan=plan_id,
            direction=direction,
        )

        return {
            "success": True,
            "customer_id": customer_id,
            "direction": direction,
            "old_plan": {
                "plan_id": current_plan_id,
                "name": current_plan["name"],
                "monthly_cost": current_plan["monthly_cost"],
            },
            "new_plan": {
                "plan_id": plan_id,
                "name": new_plan["name"],
                "monthly_cost": new_plan["monthly_cost"],
            },
            "effective_date": effective_date,
            "confirmation_number": f"CHG-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}",
            "changed_at": datetime.now(timezone.utc).isoformat(),
        }

    else:
        return {"error": f"Unknown action '{action}'. Use: list_plans, get_plan_details, change_plan."}
