"""
src/tools/account_tool.py
──────────────────────────
Customer account lookup tool for NovaTel.
In production this would call an internal CRM / account API.
Here we use an in-memory mock store that mimics realistic data.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from src.logger import get_logger

logger = get_logger(__name__)

# ── Mock customer database ─────────────────────────────────────────────────
_MOCK_ACCOUNTS: dict[str, dict] = {
    "CUST-10001": {
        "customer_id": "CUST-10001",
        "name": "Alice Johnson",
        "email": "alice.johnson@email.com",
        "phone_number": "+15551001001",
        "address": {"street": "123 Main St", "city": "Austin", "state": "TX", "zip": "78701"},
        "plan_id": "PLAN-UNLIMITED-PRO",
        "plan_name": "Unlimited Pro",
        "monthly_cost": 75.00,
        "billing_status": "current",
        "next_billing_date": "2025-03-01",
        "account_status": "active",
        "services": ["mobile", "home_internet"],
        "data_usage_gb": 38.2,
        "data_limit_gb": None,  # Unlimited
        "call_minutes_used": 420,
        "sms_sent": 215,
        "account_since": "2021-06-15",
    },
    "CUST-10002": {
        "customer_id": "CUST-10002",
        "name": "Bob Martinez",
        "email": "bob.martinez@email.com",
        "phone_number": "+15552002002",
        "address": {"street": "456 Oak Ave", "city": "Denver", "state": "CO", "zip": "80201"},
        "plan_id": "PLAN-BASIC-5G",
        "plan_name": "Basic 5G",
        "monthly_cost": 35.00,
        "billing_status": "overdue",
        "next_billing_date": "2025-02-15",
        "account_status": "active",
        "services": ["mobile"],
        "data_usage_gb": 4.8,
        "data_limit_gb": 5.0,
        "call_minutes_used": 180,
        "sms_sent": 90,
        "account_since": "2023-01-20",
    },
    "CUST-10003": {
        "customer_id": "CUST-10003",
        "name": "Carol Lee",
        "email": "carol.lee@email.com",
        "phone_number": "+15553003003",
        "address": {"street": "789 Pine Rd", "city": "Seattle", "state": "WA", "zip": "98101"},
        "plan_id": "PLAN-BUSINESS-ELITE",
        "plan_name": "Business Elite",
        "monthly_cost": 150.00,
        "billing_status": "current",
        "next_billing_date": "2025-03-05",
        "account_status": "active",
        "services": ["mobile", "home_internet", "business"],
        "data_usage_gb": 120.5,
        "data_limit_gb": None,
        "call_minutes_used": 3200,
        "sms_sent": 870,
        "account_since": "2019-11-03",
    },
}

_PHONE_INDEX: dict[str, str] = {
    v["phone_number"]: k for k, v in _MOCK_ACCOUNTS.items()
}


def get_account_info(
    customer_id: str | None = None,
    phone_number: str | None = None,
    include_usage: bool = True,
) -> dict[str, Any]:
    """
    Retrieve customer account details.

    Priority: customer_id > phone_number
    """
    if not customer_id and not phone_number:
        return {"error": "Provide either customer_id or phone_number."}

    # Resolve by phone if needed
    if not customer_id and phone_number:
        customer_id = _PHONE_INDEX.get(phone_number)
        if not customer_id:
            return {"error": f"No account found for phone number {phone_number}."}

    account = _MOCK_ACCOUNTS.get(customer_id)  # type: ignore[arg-type]
    if not account:
        return {"error": f"Account {customer_id} not found."}

    result = {k: v for k, v in account.items()}

    if not include_usage:
        result.pop("data_usage_gb", None)
        result.pop("call_minutes_used", None)
        result.pop("sms_sent", None)

    logger.info("account_lookup", customer_id=customer_id)
    return result
