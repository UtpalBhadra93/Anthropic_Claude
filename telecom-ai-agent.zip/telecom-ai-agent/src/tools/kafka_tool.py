"""
src/tools/kafka_tool.py
────────────────────────
Kafka integration tool – produces events to and consumes from topics.
Uses kafka-python with graceful degradation when Kafka is unavailable.
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any

from src.config import get_settings
from src.logger import get_logger

logger = get_logger(__name__)


def _get_producer():
    """Lazy import so tests don't require a running Kafka broker."""
    from kafka import KafkaProducer  # type: ignore
    from kafka.errors import NoBrokersAvailable  # type: ignore

    settings = get_settings()
    try:
        return KafkaProducer(
            bootstrap_servers=settings.kafka_bootstrap_servers,
            value_serializer=lambda v: json.dumps(v).encode("utf-8"),
            key_serializer=lambda k: k.encode("utf-8") if k else None,
            acks="all",
            retries=3,
            max_block_ms=5000,
        )
    except NoBrokersAvailable:
        logger.warning("kafka_no_broker", servers=settings.kafka_bootstrap_servers)
        return None


def kafka_publish_event(
    topic: str,
    event_type: str,
    payload: dict[str, Any],
    customer_id: str | None = None,
) -> dict[str, Any]:
    """
    Publish an event to a Kafka topic.

    Returns a result dict with success status and event metadata.
    """
    event_id = str(uuid.uuid4())
    envelope = {
        "event_id": event_id,
        "event_type": event_type,
        "source": "novotel-ai-agent",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "customer_id": customer_id,
        "payload": payload,
    }

    producer = _get_producer()
    if producer is None:
        # Graceful degradation – log locally and return a mock success
        logger.warning(
            "kafka_publish_degraded",
            topic=topic,
            event_type=event_type,
            event_id=event_id,
        )
        return {
            "success": True,
            "degraded": True,
            "event_id": event_id,
            "topic": topic,
            "message": "Kafka unavailable – event logged locally.",
        }

    try:
        future = producer.send(
            topic,
            key=customer_id or event_id,
            value=envelope,
        )
        record_metadata = future.get(timeout=10)
        producer.flush()
        logger.info(
            "kafka_event_published",
            topic=topic,
            partition=record_metadata.partition,
            offset=record_metadata.offset,
            event_id=event_id,
        )
        return {
            "success": True,
            "event_id": event_id,
            "topic": record_metadata.topic,
            "partition": record_metadata.partition,
            "offset": record_metadata.offset,
            "timestamp": envelope["timestamp"],
        }
    except Exception as exc:
        logger.error("kafka_publish_error", error=str(exc), topic=topic)
        return {"success": False, "error": str(exc), "event_id": event_id}
    finally:
        producer.close()


def kafka_consume_events(
    topic: str,
    max_messages: int = 10,
    timeout_ms: int = 3000,
) -> list[dict[str, Any]]:
    """
    Consume recent messages from a Kafka topic (non-blocking).
    Primarily used for health checks and debugging.
    """
    from kafka import KafkaConsumer  # type: ignore
    from kafka.errors import NoBrokersAvailable  # type: ignore

    settings = get_settings()
    messages: list[dict] = []

    try:
        consumer = KafkaConsumer(
            topic,
            bootstrap_servers=settings.kafka_bootstrap_servers,
            group_id=f"{settings.kafka_consumer_group}-debug",
            auto_offset_reset="latest",
            consumer_timeout_ms=timeout_ms,
            value_deserializer=lambda v: json.loads(v.decode("utf-8")),
            enable_auto_commit=False,
        )
        for msg in consumer:
            messages.append(
                {
                    "partition": msg.partition,
                    "offset": msg.offset,
                    "key": msg.key.decode() if msg.key else None,
                    "value": msg.value,
                    "timestamp": msg.timestamp,
                }
            )
            if len(messages) >= max_messages:
                break
        consumer.close()
    except NoBrokersAvailable:
        logger.warning("kafka_consume_no_broker")
    except Exception as exc:
        logger.error("kafka_consume_error", error=str(exc))

    return messages
