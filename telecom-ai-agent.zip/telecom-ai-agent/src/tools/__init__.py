"""
src/tools/__init__.py
──────────────────────
Tool dispatcher – maps tool names to their Python implementations.
"""
from __future__ import annotations

from typing import Any

from src.tools.kafka_tool import kafka_publish_event
from src.tools.account_tool import get_account_info
from src.tools.network_tool import check_network_status
from src.tools.plan_tool import manage_plan
from src.logger import get_logger

logger = get_logger(__name__)

TOOL_REGISTRY: dict[str, callable] = {
    "kafka_publish_event": kafka_publish_event,
    "get_account_info": get_account_info,
    "check_network_status": check_network_status,
    "manage_plan": manage_plan,
}


def execute_tool(tool_name: str, tool_input: dict[str, Any]) -> Any:
    """
    Dispatch a tool call by name with the provided inputs.
    Returns tool result (dict) or an error dict.
    """
    fn = TOOL_REGISTRY.get(tool_name)
    if fn is None:
        logger.warning("unknown_tool", tool_name=tool_name)
        return {"error": f"Tool '{tool_name}' is not registered."}

    try:
        logger.info("tool_executing", tool_name=tool_name, inputs=list(tool_input.keys()))
        result = fn(**tool_input)
        logger.info("tool_executed", tool_name=tool_name)
        return result
    except Exception as exc:
        logger.error("tool_error", tool_name=tool_name, error=str(exc))
        return {"error": f"Tool execution failed: {str(exc)}"}
