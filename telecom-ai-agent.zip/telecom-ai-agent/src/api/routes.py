"""
src/api/routes.py
──────────────────
REST API endpoints for the NovaTel AI Agent.

Endpoints:
  GET  /health              – health check
  POST /chat                – send a message to the agent
  POST /chat/stream         – streaming chat (SSE)
  POST /rag/search          – search the knowledge base
  GET  /tools               – list available tools
  POST /kafka/publish       – manually publish a Kafka event
  GET  /account/{id}        – retrieve account info
  GET  /network/status      – check network status
  GET  /plans               – list service plans
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from src.agent.agent import TelecomAgent, ChatSession
from src.rag.retriever import TelecomRAGRetriever
from src.tools.account_tool import get_account_info
from src.tools.network_tool import check_network_status
from src.tools.plan_tool import manage_plan
from src.tools.kafka_tool import kafka_publish_event
from src.config import get_settings
from src.logger import get_logger

logger = get_logger(__name__)
router = APIRouter()

# ── Singletons (cheap to create, no lazy init needed here) ────────────────
_agent = TelecomAgent()
_retriever = TelecomRAGRetriever()
_sessions: dict[str, ChatSession] = {}

settings = get_settings()


# ── Pydantic schemas ──────────────────────────────────────────────────────
class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=2000)
    session_id: str | None = None
    customer_id: str | None = None


class ChatResponse(BaseModel):
    session_id: str
    response: str
    tool_calls: int
    message_count: int
    timestamp: str


class RAGSearchRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=500)
    top_k: int = Field(default=5, ge=1, le=20)


class KafkaPublishRequest(BaseModel):
    topic: str
    event_type: str
    payload: dict[str, Any]
    customer_id: str | None = None


class PlanChangeRequest(BaseModel):
    customer_id: str
    plan_id: str
    effective_date: str | None = None


# ── Health ────────────────────────────────────────────────────────────────
@router.get("/health", tags=["System"])
async def health_check():
    return {
        "status": "ok",
        "service": settings.app_name,
        "env": settings.app_env,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# ── Chat ──────────────────────────────────────────────────────────────────
@router.post("/chat", response_model=ChatResponse, tags=["Chat"])
async def chat(request: ChatRequest):
    """
    Agentic chat endpoint. Maintains session state across multiple turns.
    """
    # Get or create session
    session_id = request.session_id
    if session_id and session_id in _sessions:
        session = _sessions[session_id]
    else:
        session = _agent.new_session(customer_id=request.customer_id)
        _sessions[session.session_id] = session
        session_id = session.session_id

    try:
        loop = asyncio.get_event_loop()
        response_text = await loop.run_in_executor(
            None, _agent.chat, session, request.message
        )
    except Exception as exc:
        logger.error("chat_error", error=str(exc), session_id=session_id)
        raise HTTPException(status_code=500, detail=f"Agent error: {str(exc)}")

    return ChatResponse(
        session_id=session.session_id,
        response=response_text,
        tool_calls=session.tool_call_count,
        message_count=len(session.messages),
        timestamp=datetime.now(timezone.utc).isoformat(),
    )


@router.post("/chat/stream", tags=["Chat"])
async def chat_stream(request: ChatRequest):
    """
    Streaming chat endpoint – returns Server-Sent Events (SSE).
    """
    session = _agent.new_session(customer_id=request.customer_id)

    async def generate():
        loop = asyncio.get_event_loop()
        gen = _agent.chat_stream(session, request.message)
        # Wrap sync generator in async
        for chunk in gen:
            yield f"data: {chunk}\n\n"
            await asyncio.sleep(0)
        yield "data: [DONE]\n\n"

    return StreamingResponse(generate(), media_type="text/event-stream")


# ── RAG ───────────────────────────────────────────────────────────────────
@router.post("/rag/search", tags=["RAG"])
async def rag_search(request: RAGSearchRequest):
    """Search the NovaTel knowledge base."""
    results = _retriever.retrieve(request.query, top_k=request.top_k)
    context = _retriever.format_context(results)
    return {
        "query": request.query,
        "results": results,
        "formatted_context": context,
        "total": len(results),
    }


# ── Tools ─────────────────────────────────────────────────────────────────
@router.get("/tools", tags=["Tools"])
async def list_tools():
    """List available Claude tools."""
    from src.agent.tools import TOOLS
    return {
        "tools": [t["toolSpec"]["name"] for t in TOOLS],
        "count": len(TOOLS),
        "details": [
            {
                "name": t["toolSpec"]["name"],
                "description": t["toolSpec"]["description"][:120] + "...",
            }
            for t in TOOLS
        ],
    }


# ── Account ───────────────────────────────────────────────────────────────
@router.get("/account/{customer_id}", tags=["Account"])
async def get_account(customer_id: str, include_usage: bool = True):
    """Retrieve customer account details."""
    result = get_account_info(customer_id=customer_id, include_usage=include_usage)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result


# ── Network ───────────────────────────────────────────────────────────────
@router.get("/network/status", tags=["Network"])
async def network_status(
    zip_code: str | None = Query(default=None),
    customer_id: str | None = Query(default=None),
    service_type: str = Query(default="all"),
):
    """Check network status and outages."""
    result = check_network_status(
        zip_code=zip_code,
        customer_id=customer_id,
        service_type=service_type,
    )
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


# ── Plans ─────────────────────────────────────────────────────────────────
@router.get("/plans", tags=["Plans"])
async def list_plans():
    """List all available NovaTel service plans."""
    return manage_plan(action="list_plans")


@router.post("/plans/change", tags=["Plans"])
async def change_plan(request: PlanChangeRequest):
    """Change a customer's service plan."""
    result = manage_plan(
        action="change_plan",
        customer_id=request.customer_id,
        plan_id=request.plan_id,
        effective_date=request.effective_date,
    )
    if not result.get("success") and "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


# ── Kafka ─────────────────────────────────────────────────────────────────
@router.post("/kafka/publish", tags=["Kafka"])
async def publish_kafka_event(request: KafkaPublishRequest):
    """Manually publish an event to the Kafka event bus."""
    result = kafka_publish_event(
        topic=request.topic,
        event_type=request.event_type,
        payload=request.payload,
        customer_id=request.customer_id,
    )
    if not result.get("success"):
        raise HTTPException(status_code=500, detail=result.get("error", "Kafka error"))
    return result
