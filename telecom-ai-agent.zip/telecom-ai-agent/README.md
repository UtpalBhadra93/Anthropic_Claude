# NovaTel AI Agent 🤖📡

> **Production-grade agentic telecom support assistant built on Claude (AWS Bedrock) — implementing all features from the Anthropic "Claude in Amazon Bedrock" course.**

---

## ✨ Features

| Feature | Implementation |
|---|---|
| **Claude via AWS Bedrock** | Converse API with retry, streaming, tool use |
| **Agentic Chat Loop** | Multi-turn, multi-tool orchestration |
| **Tool Use (4 tools)** | Account lookup, network diagnostics, plan management, Kafka events |
| **Kafka Integration** | Event publishing + graceful degradation |
| **RAG Pipeline** | BM25 + TF-IDF hybrid retrieval with RRF scoring |
| **REST API** | FastAPI with SSE streaming, Pydantic schemas |
| **Session Management** | Stateful multi-turn conversations |
| **Structured Logging** | structlog with JSON in production |
| **Test Suite** | pytest with mocks, 70%+ coverage target |
| **Docker** | Full `docker-compose` with Kafka + Kafka UI |

---

## 🏗️ Project Structure

```
telecom-ai-agent/
├── .env                        # Environment variables (never commit)
├── .env.example                # Template for env vars
├── main.py                     # Application entry point
├── Dockerfile
├── docker-compose.yml          # Kafka + Agent
├── requirements.txt
├── pyproject.toml              # pytest + coverage config
│
├── src/
│   ├── config.py               # Pydantic-Settings configuration
│   ├── logger.py               # Structured logging
│   │
│   ├── agent/
│   │   ├── claude_client.py    # AWS Bedrock Converse API wrapper
│   │   ├── agent.py            # Agentic chat loop (TelecomAgent)
│   │   └── tools.py            # JSON-Schema tool definitions
│   │
│   ├── tools/
│   │   ├── __init__.py         # Tool dispatcher (execute_tool)
│   │   ├── kafka_tool.py       # ① Kafka publish/consume
│   │   ├── account_tool.py     # ② Customer account lookup
│   │   ├── network_tool.py     # ③ Network diagnostics
│   │   └── plan_tool.py        # ④ Plan management
│   │
│   ├── rag/
│   │   ├── knowledge_base.py   # NovaTel KB documents
│   │   └── retriever.py        # Hybrid BM25+TF-IDF+RRF retriever
│   │
│   └── api/
│       ├── app.py              # FastAPI factory
│       └── routes.py           # REST endpoints
│
├── tests/
│   ├── conftest.py             # Shared fixtures + mock Bedrock
│   ├── test_tools.py           # All 4 tools + dispatcher
│   ├── test_agent.py           # Agentic loop + Claude client
│   ├── test_rag.py             # RAG retriever
│   ├── test_api.py             # FastAPI integration tests
│   └── test_config.py          # Config loading
│
└── scripts/
    └── demo_chat.py            # Rich CLI demo
```

---

## 🚀 Quick Start

### 1. Prerequisites
- Python 3.11+
- AWS account with Bedrock access (Claude 3.5 Sonnet enabled)
- Docker (optional, for Kafka)

### 2. Install

```bash
git clone <repo>
cd telecom-ai-agent
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
```

### 3. Configure

```bash
cp .env.example .env
# Edit .env and add your AWS credentials
```

Required values in `.env`:
```
AWS_ACCESS_KEY_ID=your_key
AWS_SECRET_ACCESS_KEY=your_secret
AWS_REGION=us-east-1
```

### 4. Start Kafka (optional)

```bash
docker-compose up kafka kafka-ui -d
# Kafka UI: http://localhost:8080
```

### 5. Run the API

```bash
python main.py
# API docs: http://localhost:8000/docs
```

### 6. Interactive Demo

```bash
python scripts/demo_chat.py --customer CUST-10001
```

---

## 🔧 The Four Tools

### 1. `kafka_publish_event` 🔴 Kafka
Publishes structured events to NovaTel's Kafka event bus.
- **Topics**: `telecom.customer.events`, `telecom.network.alerts`, `telecom.billing.events`
- Graceful degradation when Kafka is unavailable

### 2. `get_account_info` 👤 Account
Retrieves full customer account details: plan, usage, billing status, services.
- Lookup by `customer_id` or `phone_number`
- Optional usage stats inclusion

### 3. `check_network_status` 📡 Network
Returns real-time network health for a given area.
- Active incidents, signal quality, severity levels
- Resolves ZIP from customer account automatically

### 4. `manage_plan` 📋 Plan Management
Lists plans and processes upgrades/downgrades.
- Actions: `list_plans`, `get_plan_details`, `change_plan`
- Returns confirmation number and effective date

---

## 🧪 Running Tests

```bash
# All tests with coverage
pytest

# Specific test file
pytest tests/test_tools.py -v

# Skip coverage
pytest --no-cov -v
```

Expected output: **5 test files, ~50 tests, ≥70% coverage**

---

## 📡 API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/v1/health` | Health check |
| `POST` | `/api/v1/chat` | Agentic chat (stateful) |
| `POST` | `/api/v1/chat/stream` | Streaming chat (SSE) |
| `POST` | `/api/v1/rag/search` | Knowledge base search |
| `GET` | `/api/v1/tools` | List available tools |
| `GET` | `/api/v1/account/{id}` | Customer account info |
| `GET` | `/api/v1/network/status` | Network status |
| `GET` | `/api/v1/plans` | List service plans |
| `POST` | `/api/v1/plans/change` | Change customer plan |
| `POST` | `/api/v1/kafka/publish` | Publish Kafka event |

Full interactive docs at **http://localhost:8000/docs**

---

## 🔐 Security Notes

- Never commit `.env` to source control (it's in `.gitignore`)
- Rotate `API_SECRET_KEY` in production
- Use IAM roles instead of static credentials in AWS environments
- Enable HTTPS via a reverse proxy (nginx/ALB) in production

---

## 🎓 Course Features Implemented

Based on the Anthropic "Claude in Amazon Bedrock" course:

- ✅ Bedrock Converse API (multi-turn, system prompts)
- ✅ Tool use / function calling with JSON Schema
- ✅ Agentic loop with tool result feedback
- ✅ RAG: text chunking, BM25, vector similarity, hybrid retrieval
- ✅ Streaming responses
- ✅ Prompt engineering (system prompts, structured instructions)
- ✅ Production patterns (retries, logging, error handling)
- ✅ Client/Server/Host architecture separation
