"""
scripts/demo_chat.py
─────────────────────
Interactive CLI demo for the NovaTel agentic chat.
Simulates a real customer support conversation.

Usage:
    python scripts/demo_chat.py
    python scripts/demo_chat.py --customer CUST-10001
"""
from __future__ import annotations

import argparse
import sys

sys.path.insert(0, ".")

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

from src.agent.agent import TelecomAgent
from src.config import get_settings

console = Console()


def run_demo(customer_id: str | None = None) -> None:
    settings = get_settings()
    console.print(
        Panel.fit(
            f"[bold cyan]{settings.app_name}[/bold cyan]\n"
            "[dim]Powered by Claude on AWS Bedrock[/dim]\n"
            "[dim]Type 'quit' to exit[/dim]",
            border_style="cyan",
        )
    )

    agent = TelecomAgent()
    session = agent.new_session(customer_id=customer_id)

    console.print(f"[dim]Session ID: {session.session_id}[/dim]")
    if customer_id:
        console.print(f"[dim]Customer ID: {customer_id}[/dim]")
    console.print()

    while True:
        try:
            user_input = Prompt.ask("[bold green]You[/bold green]")
        except (KeyboardInterrupt, EOFError):
            console.print("\n[yellow]Goodbye![/yellow]")
            break

        if user_input.lower() in ("quit", "exit", "q"):
            console.print("[yellow]Goodbye![/yellow]")
            break

        if not user_input.strip():
            continue

        console.print("[dim]Aria is thinking...[/dim]")

        try:
            response = agent.chat(session, user_input)
            console.print(
                Panel(
                    response,
                    title="[bold blue]Aria[/bold blue]",
                    border_style="blue",
                )
            )
        except Exception as exc:
            console.print(f"[red]Error: {exc}[/red]")

        console.print(
            f"[dim]Messages: {len(session.messages)} | Tool calls: {session.tool_call_count}[/dim]\n"
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="NovaTel AI Agent Demo")
    parser.add_argument("--customer", "-c", default=None, help="Customer ID")
    args = parser.parse_args()
    run_demo(customer_id=args.customer)
