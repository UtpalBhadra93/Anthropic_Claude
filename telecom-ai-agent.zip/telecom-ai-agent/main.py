"""
main.py
────────
Entry point for the NovaTel AI Agent application.
Run with:  python main.py  or  uvicorn main:app --reload
"""
import uvicorn
from src.api.app import create_app
from src.config import get_settings
from src.logger import get_logger

logger = get_logger(__name__)
app = create_app()


if __name__ == "__main__":
    settings = get_settings()
    logger.info(
        "starting_server",
        host=settings.app_host,
        port=settings.app_port,
        env=settings.app_env,
    )
    uvicorn.run(
        "main:app",
        host=settings.app_host,
        port=settings.app_port,
        reload=not settings.is_production,
        log_level=settings.log_level.lower(),
    )
